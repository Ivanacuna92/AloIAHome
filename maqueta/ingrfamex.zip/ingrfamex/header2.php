<!DOCTYPE html>
<html lang="es">

<head>
  <title>INGFRAMEX</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="INGFRAMEX - Especialistas en pirómetros y cámaras infrarrojas Optris para medición de temperatura industrial de precisión">
  <meta name="keywords" content="pirómetros, cámaras infrarrojas, Optris, medición temperatura, termometría industrial, instrumentos medición">
  <meta name="author" content="INGFRAMEX">
  
  <!-- Open Graph Meta Tags -->
  <meta property="og:title" content="INGFRAMEX - Pirómetros y Cámaras Infrarrojas Optris">
  <meta property="og:description" content="Especialistas en pirómetros y cámaras infrarrojas Optris para medición de temperatura industrial de precisión">
  <meta property="og:type" content="website">
  <meta property="og:image" content="images/logo-ingframex.png">

  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,400,700" rel="stylesheet">
  <link rel="stylesheet" href="fonts/ionicons/css/ionicons.min.css">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/animate.css">
  <link rel="stylesheet" href="css/owl.carousel.min.css">
  <link rel="stylesheet" href="css/jquery.fancybox.min.css">
  <link rel="stylesheet" href="css/style.css">
  
  <!-- Favicon -->
  <link rel="icon" type="image/png" href="images/favicon.png">
  <link rel="shortcut icon" type="image/png" href="images/favicon.png">

  <style>
    .site-navbar {
      background: #fff;
      box-shadow: 0 2px 5px rgba(0,0,0,0.1);
      padding: 1rem 0;
    }
    
    .site-navbar .navbar-brand img {
      height: 50px;
      width: auto;
    }
    
    .site-navbar .navbar-nav .nav-link {
      color: #6B3AA0;
      font-weight: 500;
      padding: 0.5rem 2rem;
      text-transform: uppercase;
      font-size: 0.9rem;
      letter-spacing: 1px;
    }
    
    .site-navbar .nav-item {
      margin-right: 10px;
    }
    
    .site-navbar .nav-item:nth-child(2) {
      margin-right: 30px;
    }
    
    .site-navbar .nav-item:last-child {
      margin-right: 0;
    }
    
    .site-navbar .navbar-nav .nav-link:hover {
      color: #4A2970;
    }
    
    .site-navbar .dropdown-menu {
      border: none;
      box-shadow: 0 5px 20px rgba(0,0,0,0.1);
      border-radius: 5px;
      padding: 0.5rem 0;
      margin-top: 0.5rem;
      z-index: 1050;
    }
    
    .site-navbar .dropdown-item {
      padding: 0.5rem 1.5rem;
      font-size: 0.9rem;
      color: #666;
      transition: all 0.3s ease;
    }
    
    .site-navbar .dropdown-item:hover {
      background: #f8f9fa;
      color: #6B3AA0;
      padding-left: 2rem;
    }
    
    .site-navbar .navbar-toggler {
      border: none;
      padding: 0.25rem 0.5rem;
    }
    
    .site-navbar .navbar-toggler-icon {
      background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 30 30'%3e%3cpath stroke='rgba%2833, 37, 41, 0.75%29' stroke-linecap='round' stroke-miterlimit='10' stroke-width='2' d='M4 7h22M4 15h22M4 23h22'/%3e%3c/svg%3e");
    }
    
    @media (max-width: 768px) {
      .site-navbar .navbar-nav {
        text-align: center;
        padding-top: 1rem;
      }
      
      .site-navbar .nav-item {
        margin-right: 0;
        margin-bottom: 0.5rem;
      }
      
      .site-navbar .navbar-nav .nav-link {
        padding: 0.5rem 1rem;
      }
      
      .site-navbar .dropdown-menu {
        text-align: center;
        box-shadow: none;
        border-top: 1px solid #eee;
      }
    }
  </style>
</head>

<body>
  <nav class="navbar navbar-expand-lg site-navbar">
    <div class="container">
      <a class="navbar-brand" href="index2.php">
        <img src="images/logo-ingframex.png" alt="INGFRAMEX">
      </a>
      
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      
      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="productosDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Productos
            </a>
            <div class="dropdown-menu" aria-labelledby="productosDropdown">
              <a class="dropdown-item" href="/camaras_infrarojas.php">Cámaras Infrarojas</a>
              <a class="dropdown-item" href="/pirometros.php">Pirómetros</a>  
            </div>
          </li>
          <li class="nav-item dropdown">
             <a class="nav-link dropdown-toggle" href="#" id="aplicacionesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Aplicaciones</a>
            <div class="dropdown-menu" aria-labelledby="aplicacionesDropdown">
              <a class="dropdown-item" href="/automotriz.php">Automotriz</a>
              <a class="dropdown-item" href="/deteccion_incendios.php">Detección de Incendios</a>
              <a class="dropdown-item" href="/electronico.php">Electrónica</a>
              <a class="dropdown-item" href="/monitoreo_bateria.php">Monitoreo de Batería</a>
              <a class="dropdown-item" href="/plasticos.php">Plástico</a>
              <a class="dropdown-item" href="/solar.php">Solar</a>
              <a class="dropdown-item" href="/vidrio.php">Vidrio</a>
            </div>
          </li>
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="industriaDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
              Industria
            </a>
            <div class="dropdown-menu" aria-labelledby="industriaDropdown">
              <a class="dropdown-item" href="/aceria.php">Acería</a>
              <a class="dropdown-item" href="/alimentos_y_bebidas.php">Alimentos y Bebidas</a>
              <a class="dropdown-item" href="/ciencias_de_la_vida.php">Ciencias de la Vida</a>
              <a class="dropdown-item" href="/hvac.php">HVAC</a>
              <a class="dropdown-item" href="/industria_primaria.php">Industria Primaria</a>
              <a class="dropdown-item" href="/instrumentos_de_medicion.php">Instrumentos de Medición</a>
              <a class="dropdown-item" href="/mantenimiento_industrial.php">Mantenimiento Industrial</a>
              <a class="dropdown-item" href="/metal.php">Metal</a>
              <a class="dropdown-item" href="/metrologia.php">Metrología</a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>