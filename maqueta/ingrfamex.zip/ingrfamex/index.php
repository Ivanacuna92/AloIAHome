<?php include('header.php') ?>
    <div class="top-shadow"></div>
    <section class="home-slider owl-carousel" style="overflow:hidden;height:60vh !important">
      <!-- <div class="slider-item" style="background-image: url('images/banner-2.jpg');"> -->
      <div class="slider-item" style="background-image: url('https://images.pexels.com/photos/459670/pexels-photo-459670.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=750&w=1260'); background-position-y:-35vh;">
        <div class="container">
          <div class="row slider-text align-items-center justify-content-center">
            <div class="col-lg-7 text-center col-sm-12 element-animate">
              <!-- <div class="btn-play-wrap mx-auto"><p class="mb-4"><a href="https://vimeo.com/59256790" data-fancybox data-ratio="2" class="btn-play"><span class="ion ion-ios-play"></span></a></p></div> -->
              <h1 class="mb-6"><span>INGFRAMEX</span></h1>
              <p class="mb-5 w-75">Tecnología, ingeniería y soluciones para la mejora de tu empresa.</p>
            </div>
          </div>
        </div>
        
      </div>

    </section>
    <!-- END slider -->
    </div>
    
    <section class="section bg-light">
      <div class="container">
        <div class="row">
          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <a href="/optris">
                <div class="icon mb-3">
                  <img src="https://www.optris.es/tl_files/styles/pics/optris-logo.png" alt="">  
                </div>
              </a>  
              <div class="media-body">
                <a href="/optris">
                  <h3 class="heading">Optris</h3>
                </a>
                <p>La mejor tecnología para la medición de temperatura sin contacto, cámaras y sensores fijos o portátiles.</p>
                <a class="btn btn-danger" href="https://www.optris.com/" target="_blank">Ir a sitio Optris</a>
              </div>
            </div>
          </div>

          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <a href="/telea">
                <div class="icon mb-3">
                  <img src="/images/logo_telea_index_web_ok.png" alt="" style="width:70%;">
                </div>
              </a>
              <div class="media-body">
                <a href="/telea">
                  <h3 class="heading">Telea</h3>
                </a>
                <p>Sistemas de seguridad y circuito cerrado para el monitoreo de tus procesos industriales.</p>
                <a class="btn btn-danger" href="http://www.telea.com/en/" target="_blank">Ir a sitio TELEA</a>
              </div>
            </div> 
          </div>

          <div class="col-md-6 col-lg-4 element-animate ">
            <div class="media block-6 d-block text-center">
              <a href="/siemens">
                <div class="icon mb-3">
                  <img src="https://new.siemens.com/etc.clientlibs/siemens-sites/components/content/header/clientlibs/resources/logo/siemens-logo-default.svg" alt="" style="width:70%">
                </div>
              </a>
              <div class="media-body">
                <a href="/siemens">
                  <h3 class="heading">Siemens</h3>
                </a>
                <p>Innovación, velocidad, y flexibilidad, que ayudan a hacerte mas competitivo y estar al frente de la evolución de la demanda del mercado.</p>
                <a class="btn btn-danger" href="https://new.siemens.com/global/en/products/automation/process-instrumentation.html" target="_blank">Ir a sitio Siemens</a>                
              </div>
            </div> 
          </div>
        </div>

        <div class="row mb-5 element-animate ">
          <div class="col-12 text-center">
            <h2>Somos la solución para tu problema de medición</h2>
          </div>
        </div>
        <div class="row mt-2 mb-4 element-animate ">
            <div class="col-sm-12 col-md-3">
                <h3>Temperatura</h3>
                <ul>
                    <li>Medición de temperatura sin contacto tecnología infrarroja </li>
                    <li>Medición de temperatura de contacto</li>
                </ul>
            </div>
            <div class="col-sm-12 col-md-3 element-animate ">
                <h3>Flujo</h3>
                <ul>
                    <li>Transferencia de custodia</li>
                    <li>Dosificación</li>
                    <li>Descarga de agua</li>
                    <li>Control de combustión</li>
                </ul>
            </div>
            <div class="col-sm-12 col-md-3 element-animate ">
                <h3>Nivel</h3>
                <ul>
                    <li>Control de inventarios</li>
                    <li>Procesos de producción</li>
                </ul>
            </div>
            <div class="col-sm-12 col-md-3 element-animate ">
                <h3>Presión</h3>
                <ul>
                    <li>Monitoreo de procesos</li>
                    <li>Seguridad de proceso</li>
                    <li>Control de calidad</li>
                    <li>Transferencias de custodia</li>
                </ul>
            </div>
        </div>
      </div>
    </section>

<?php /*
    <section class="section border-t pb-0">
      <div class="container">
        <div class="row justify-content-center mb-5 element-animate">
          <div class="col-md-8 text-center">
            <h2 class=" heading mb-4">Nosotros</h2>
            <p class="mb-5 lead">Somos una compañía comprometida en brindar soluciones a las necesidades de la industria en México. Con nuestra ingeniería mejoramos, controlamos y eficientamos sus procesos de producción para que su industria logre una alta calidad en sus productos, un ahorro de costos y energía.</p>
          </div>
        </div>
      </div>
      <div class="container-fluid">
        <div class="row no-gutters">
          <div class="col-md-4 element-animate">
            <a href="#" class="link-thumbnail">
              <!-- <h3>Ducting Design in Colorado</h3>
              <span class="ion-plus icon"></span> -->
              <img src="images/telea-1.jpg" alt="Image" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="#" class="link-thumbnail">
              <!-- <h3>Tanks Project In California</h3>
              <span class="ion-plus icon"></span> -->
              <img src="images/optris-6.png" alt="Image" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="#" class="link-thumbnail">
              <!-- <h3>Structural Design in New York</h3>
              <span class="ion-plus icon"></span> -->
              <img src="images/optris-7.png" alt="Image" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="#" class="link-thumbnail">
              <!-- <h3>Stacks Design</h3>
              <span class="ion-plus icon"></span> -->
              <img src="images/telea-3.jpg" alt="Image" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="#" class="link-thumbnail">
              <!-- <h3>Intercate Custom</h3>
              <span class="ion-plus icon"></span> -->
              <img src="images/optris-5.png" alt="Image" class="img-fluid">
            </a>
          </div>
          <div class="col-md-4 element-animate">
            <a href="#" class="link-thumbnail">
              <!-- <h3>Banker Design</h3>
              <span class="ion-plus icon"></span> -->
              <img src="images/optris-2.jpg" alt="Image" class="img-fluid">
            </a>
          </div>
        </div>
        
      </div>
    </section> */ ?>
<?php include('footer.php') ?>
