
    <style>
        /* Modern Footer Styles */       
        .contact-header {
            text-align: center;
            margin-bottom: 60px;
        }
        
        .contact-header h2 {
            font-size: 2.5rem;
            font-weight: 300;
            color: #333;
            margin-bottom: 1rem;
        }
        
        .contact-header p {
            font-size: 1.1rem;
            color: #666;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .contact-form {
            background: white;
            padding: 40px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0,0,0,0.08);
        }
        
        .contact-form label {
            font-weight: 500;
            color: #333;
            margin-bottom: 8px;
        }
        
        .contact-form .form-control {
            border: 2px solid #e0e0e0;
            border-radius: 5px;
            padding: 12px 15px;
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .contact-form .form-control:focus {
            border-color: #2563eb;
            box-shadow: 0 0 0 0.2rem rgba(37, 99, 235, 0.25);
        }
        
        .contact-form textarea {
            resize: vertical;
        }
        
        .btn-send {
            background: #2563eb;
            color: white;
            border: none;
            padding: 14px 40px;
            font-size: 1rem;
            font-weight: 500;
            border-radius: 5px;
            transition: all 0.3s ease;
            cursor: pointer;
        }
        
        .btn-send:hover {
            background: #1d4ed8;
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(37, 99, 235, 0.3);
        }
        
        .contact-info {
            padding: 40px;
        }
        
        .contact-info-item {
            display: flex;
            align-items: flex-start;
            margin-bottom: 30px;
        }
        
        .contact-icon {
            width: 50px;
            height: 50px;
            background: #2563eb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-right: 20px;
            flex-shrink: 0;
        }
        
        .contact-icon i {
            color: white;
            font-size: 20px;
        }
        
        .contact-text h4 {
            font-size: 1.1rem;
            font-weight: 600;
            color: #333;
            margin-bottom: 5px;
        }
        
        .contact-text p {
            color: #666;
            margin: 0;
            line-height: 1.6;
        }
        
        .contact-text a {
            color: #2563eb;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .contact-text a:hover {
            color: #1d4ed8;
        }
        
        /* Footer Styles */
        .site-footer {
            background: #1a1a1a;
            color: #ccc;
            padding: 60px 0 30px;
        }
        
        .footer-widget h3 {
            font-size: 1.3rem;
            font-weight: 500;
            color: white;
            margin-bottom: 20px;
        }
        
        .footer-widget p {
            line-height: 1.8;
            color: #999;
        }
        
        .footer-social {
            display: flex;
            gap: 10px;
            margin-top: 20px;
        }
        
        .footer-social a {
            width: 40px;
            height: 40px;
            background: #2563eb;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            text-decoration: none;
            transition: all 0.3s ease;
        }
        
        .footer-social a:hover {
            background: #1d4ed8;
            transform: translateY(-3px);
        }
        
        .footer-link {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        
        .footer-link li {
            margin-bottom: 15px;
            color: #999;
            line-height: 1.8;
        }
        
        .footer-link a {
            color: #2563eb;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        
        .footer-link a:hover {
            color: #1d4ed8;
        }
        
        .footer-bottom {
            border-top: 1px solid #333;
            margin-top: 40px;
            padding-top: 30px;
            text-align: center;
            color: #666;
        }
        
        .loader-icon {
            stroke: #2563eb !important;
        }
    </style>
    
    <section id="contact" class="contact-section">
      <div class="container">
        <div class="contact-header">
            <h2>Contáctanos</h2>
            <p>Estamos aquí para ayudarte con tus necesidades industriales</p>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-8 col-lg-6 mb-5">
            <form action="#" method="post" class="contact-form">
              <div class="row">
                <div class="col-md-6 form-group">
                  <label for="name">Nombre *</label>
                  <input type="text" id="name" class="form-control" required>
                </div>
                <div class="col-md-6 form-group">
                  <label for="phone">Teléfono</label>
                  <input type="tel" id="phone" class="form-control" pattern="[0-9\-\+\s\(\)]+">
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 form-group">
                  <label for="email">Email *</label>
                  <input type="email" id="email" class="form-control" required>
                </div>
              </div>
              <div class="row">
                <div class="col-md-12 form-group">
                  <label for="message">Mensaje *</label>
                  <textarea name="message" id="message" class="form-control" cols="30" rows="8" required minlength="10"></textarea>
                </div>
              </div>
              <div class="row">
                <div class="col-md-6 form-group">
                  <input type="submit" value="Enviar mensaje" class="btn-send">
                </div>
              </div>
            </form>
          </div>
      
        </div>
      </div>
    </section>


    <footer class="site-footer" role="contentinfo">
      <div class="container">
        <div class="row">
          <div class="col-md-4 mb-5">
            <div class="footer-widget">
              <h3>Nuestras redes sociales</h3>
              <p>Conéctate con nosotros para descubrir nuestras soluciones industriales, conocer casos de éxito, ver avances en tiempo real y estar al tanto de nuestras novedades, lanzamientos y proyectos.
              </p>
              <p> 📌 Encuéntranos en:</p>
              <div class="footer-social">
                <a href="https://www.facebook.com/ingframex/"><i class="fa fa-facebook"></i></a>
                <a href="https://mx.linkedin.com/company/mxingframex"><i class="fa fa-linkedin"></i></a>
                <a href="https://www.instagram.com/ingframex/"><i class="fa fa-instagram"></i></a>
              </div>
            </div>
          </div>
          <div class="col-md-5 mb-5">
            <div class="footer-widget">
              <h3>Información de Contacto</h3>
              <ul class="footer-link">
                <li>
                  <strong>Monterrey:</strong><br>
                  Ave Bernardo Reyes 1805 Nte Col. Industrial, Monterrey, N.L 64440
                </li>
                <li>
                  <strong>Querétaro:</strong><br>
                  Armando Birlain Schaffler 2001 Corporativo 1 Piso 11 Central Park, Querétaro, Querétaro 76090
                </li>
                <li>
                  <strong>Horarios</strong><br>
                  Nuestros horarios en los que podremos atenderte son los siguientes<br><br>
                  <strong>Lunes - Viernes</strong><br>
                  8 AM - 4 PM<br>
                  <strong>Sábado</strong><br>
                  8 AM - 3 PM
                </li>
                <li>
                  <strong>Teléfono:</strong> <a href="tel:+524421243334">+52 442 124 3334</a>
                </li>
                <li>
                  <strong>Email:</strong> <a href="mailto:contacto@ingframex.com">contacto@ingframex.com</a>
                </li>
              </ul>
            </div>
          </div>
          <div class="col-md-3 mb-5">
            <div class="footer-widget">
              <h3>Certificaciones</h3>
              <ul class="footer-link">
                <li><a href="/Certificate_Ingframexp_Mexico_2019_11.pdf">Certificado Optris</a></li>
                <li><a href="/CERTIFICATE DISTRIBUTOR_Ingfrarex.pdf">Certificado Telea</a></li>
              </ul>
            </div>
          </div>
        </div>
        <div class="footer-bottom">
          <p>&copy; <script>document.write(new Date().getFullYear());</script> INGFRAMEX Querétaro. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
    <!-- END footer -->

    <!-- loader -->
    <div id="loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path loader-icon" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#2563eb"/></svg></div>

    <script src="js/jquery-3.2.1.min.js"></script>
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/owl.carousel.min.js"></script>
    <script src="js/jquery.waypoints.min.js"></script>
    <script src="js/jquery.fancybox.min.js"></script>
    <script src="js/main.js"></script>

    <script>
      $('#contact-button').on('click', function(){
        $("html, body").animate({ scrollTop: $('#contact').offset().top }, 1000);
      })
      $('input[type="submit"]').on('click', function(e){
        e.preventDefault()
        let data = {}

        data.name = $('#name').val()
        data.phone = $('#phone').val()
        data.email = $('#email').val()
        data.message = $('#message').val()

        $.ajax({
          url:  "https://linupsales.com/api/websites",
          method: "POST",
          dataType: "json",
          crossDomain: true,
          contentType: "application/json; charset=utf-8",
          data: JSON.stringify(data),
          cache: false,
          beforeSend: function (xhr) {
              /* Authorization header */
              xhr.setRequestHeader("Authorization", "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImp0aSI6Ijc5MTIyYzEwYmNjZWIwNzU5ZDlhODZhOTA4ZTk1YThmNjQ5NDM4ZWM4MWNlYmY1MWJkMWQ3ZTJmNWRiMmQ5NzAxZmZlNmRhODAzYmEwYWZlIn0.eyJhdWQiOiIxIiwianRpIjoiNzkxMjJjMTBiY2NlYjA3NTlkOWE4NmE5MDhlOTVhOGY2NDk0MzhlYzgxY2ViZjUxYmQxZDdlMmY1ZGIyZDk3MDFmZmU2ZGE4MDNiYTBhZmUiLCJpYXQiOjE1NzI5MDIyNDAsIm5iZiI6MTU3MjkwMjI0MCwiZXhwIjoxNjA0NTI0NjQwLCJzdWIiOiI5Iiwic2NvcGVzIjpbXX0.TS11FgtT44Rz8djXdj4xl9n_mdtMCHf-AkbBKGQS82Q-ACyMAwuhxRF6hX4oS2Ysvx3Im2bTa3H3L0-_IZnA-Uf37fPS12QbYDfJTMW9GlUdc8C9VLbr6LXGstUm4T1QlO3GzpPdnhqT3JSNT3pmupIWFMlXNFqiq7Pi1WA-j73-xxAzumOFy_fWh8MeEgUOINUZP0KKzcieuUpAZEdHryeXx0gI9oyOtv2Iv90zFGJVsr5KG6ftaQBGJsfBre_Q6HDq0vArF3id0loJLCelAN_uwViojz_yOijeDh3PSy5G7U8mlyJKXGSeqZxE8nBd6wCoXTV2c-ifqGLmodCycUb07suOLqwn66DwqEBJJj4N94W41cZEfx9YfgWYA93UKog8KsVgcl6gh7ZrtowW3YrZZNuZHQi4MME5v1uh-lDWasAJ6u4t7zTKY9c6tscxgyKBoHGTsNOoNcTXZjzZPIOBxjraVIGcHKbVKzAyR3D1E4OkhrDVLx8okfZF2r1RND6eHJT7y4aAGYuTgii3oerAPkVeDhd2ZYwCUmpV6cMI7HB17qCpdbWYvUP0sMvXutpVPeLC41iqato6EmnhJLl6nDyA7mtnjcgE3oykNXkkGgoimA1CV9ooXVnTANbOyMlKQVmXnO5LOaNUrOSyW_e0lhjKk3VhlqRwpXaiPoM");
              xhr.setRequestHeader("X-Mobile", "false");
          },
          success: function (data) {
            $('#name').val('')
            $('#phone').val('')
            $('#email').val('')
            $('#message').val('')
            alert('Gracias por tu mensaje');
          },
          error: function (jqXHR, textStatus, errorThrown) {
            alert('Ocurrió un error! Por favor contáctanos via telefónica');
          }
        });
      })
    </script>
    
  </body>
</html>
