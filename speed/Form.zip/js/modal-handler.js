// Manejo del modal de cotización
let currentServices = [];

function showModal() {
    const modal = document.getElementById('cotizacionModal');
    if (modal) {
        modal.style.display = 'flex';
        document.getElementById('submitPdfForm').disabled = true;
    }
}

function updateModalJSON() {
    const services = collectServices();
    
    const client = {
        companyName: document.getElementById('companyName')?.value.trim() || '',
        contactName: document.getElementById('contactName')?.value.trim() || '',
        contactPhone: document.getElementById('contactPhone')?.value.trim() || '',
        contactEmail: document.getElementById('contactEmail')?.value.trim() || ''
    };

    const dataToSend = { services: services, client: client };
    
    const hiddenInput = document.getElementById('modal_services_json');
    if (hiddenInput) {
        hiddenInput.value = JSON.stringify(dataToSend);
    }
}

function closeModal() {
    const modal = document.getElementById('cotizacionModal');
    if (modal) {
        modal.style.display = 'none';
    }
}

function validateField(field) {
    if (!field) return false;
    
    let isValid = false;
    
    switch(field.id) {
        case 'companyName':
            isValid = field.value.trim().length > 0;
            break;
        case 'contactName':
            isValid = field.value.trim().length > 0;
            break;
        case 'contactPhone':
            const phoneRegex = /^\d{10}$/;
            isValid = phoneRegex.test(field.value);
            break;
        case 'contactEmail':
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            isValid = emailRegex.test(field.value);
            break;
    }
    
    if (isValid) {
        field.classList.remove('is-invalid');
        field.classList.add('is-valid');
    } else {
        field.classList.remove('is-valid');
        field.classList.add('is-invalid');
    }
    
    return isValid;
}

function checkAllFieldsValid() {
    const companyName = document.getElementById('companyName');
    const contactName = document.getElementById('contactName');
    const contactPhone = document.getElementById('contactPhone');
    const contactEmail = document.getElementById('contactEmail');
    const submitBtn = document.getElementById('submitPdfForm');
    
    if (!companyName || !contactName || !contactPhone || !contactEmail || !submitBtn) {
        return;
    }
    
    const companyNameValid = validateField(companyName);
    const contactNameValid = validateField(contactName);
    const contactPhoneValid = validateField(contactPhone);
    const contactEmailValid = validateField(contactEmail);
    
    submitBtn.disabled = !(companyNameValid && contactNameValid && contactPhoneValid && contactEmailValid);
}

function clearFormValidation() {
    const formInputs = document.querySelectorAll('#pdfModalForm .form-control');
    formInputs.forEach(input => {
        input.classList.remove('is-invalid');
        input.classList.remove('is-valid');
    });
}

// Configuración de eventos para el modal
document.addEventListener('DOMContentLoaded', function() {
    setupModalEvents();
});

function setupModalEvents() {
    // Eventos para cerrar el modal
    const closeModalBtn = document.getElementById('closeModal');
    const cancelModalBtn = document.getElementById('cancelModal');
    
    if (closeModalBtn) {
        closeModalBtn.addEventListener('click', closeModal);
    }
    
    if (cancelModalBtn) {
        cancelModalBtn.addEventListener('click', closeModal);
    }
    
    // Validación en tiempo real para los inputs del formulario
    const formInputs = document.querySelectorAll('#pdfModalForm .form-control');
    formInputs.forEach(input => {
        input.addEventListener('input', function() {
            validateField(this);
            checkAllFieldsValid();
        });
        input.addEventListener('blur', function() {
            validateField(this);
            checkAllFieldsValid();
        });
    });
    
    // Validación específica para el teléfono (solo números)
    const phoneInput = document.getElementById('contactPhone');
    if (phoneInput) {
        phoneInput.addEventListener('input', function() {
            this.value = this.value.replace(/[^0-9]/g, '');
            validateField(this);
            checkAllFieldsValid();
        });
    }
    
    // Cerrar el modal si se hace clic fuera del mismo
    window.addEventListener('click', function(event) {
        const modal = document.getElementById('cotizacionModal');
        if (event.target === modal) {
            closeModal();
        }
    });
    
    // Envío del formulario del modal
    const modalForm = document.getElementById('pdfModalForm');
    if (modalForm) {
        modalForm.addEventListener('submit', function(e) {
            const companyName = document.getElementById('companyName');
            const contactName = document.getElementById('contactName');
            const contactPhone = document.getElementById('contactPhone');
            const contactEmail = document.getElementById('contactEmail');
            
            const companyNameValid = validateField(companyName);
            const contactNameValid = validateField(contactName);
            const contactPhoneValid = validateField(contactPhone);
            const contactEmailValid = validateField(contactEmail);
            
            if (!(companyNameValid && contactNameValid && contactPhoneValid && contactEmailValid)) {
                e.preventDefault();
                alert('Por favor completa correctamente todos los campos.');
            } else {
                updateModalJSON();
            }
        });
    }
}